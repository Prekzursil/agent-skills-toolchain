# ast-integrate-platform

The ast-integrate platform, packaged as an installable Claude Code plugin.

## Install

    python bin/astplugin.py install --package <package>.zip --prefix <install-prefix>

`--prefix` is an explicit directory. Nothing is written outside it, and `--live` (default
`<prefix>/live`) is the deployment target — the plugin never writes to a real `~/.claude` unless
you point `--live` there yourself.

## Lifecycle

`install` -> `update` -> (`repair` | `rollback`) -> `uninstall`. Every one is transactional: a
failure anywhere replays the inverse of each applied step, so a failed install leaves no partial
state. `uninstall` refuses to run without an explicit `--retain-user-data` or `--purge-user-data`.

## Safety properties this package asserts, not documents

* deny-by-default payload allowlist plus an independent forbidden-content scan (no `.git`, caches,
  logs, transcripts, credentials) and a hard size/file budget;
* a deterministic archive (sorted entries, fixed timestamps, LF) so two builds of the same content
  are byte-identical;
* a two-directional drift classifier — live-unique content is never overwritten, and a diverged
  file produces a decision packet instead of a guess;
* every health probe ships a both-states control proving it fails when its invariant breaks;
* deny-by-default log redaction; the plugin never reads a credential store.

## License

MIT. See `LICENSE`.
