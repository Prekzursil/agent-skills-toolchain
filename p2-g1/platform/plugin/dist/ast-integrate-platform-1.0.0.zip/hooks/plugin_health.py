"""Health hook: reports the installed plugin's health without ever blocking a session.

Hook contract: exit 0 always. A hook that can fail the session is a worse outcome than a missed
health warning, so this one degrades loudly on stdout and still exits 0 (the fail-open row is
declared in the exec policy for `kind: hook`).
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))


def main() -> int:
    prefix = os.environ.get("ASTPLUGIN_PREFIX")
    if not prefix:
        print("astplugin: ASTPLUGIN_PREFIX is unset; skipping the health probe")
        return 0
    try:
        from astplugin.health import health_check
        from astplugin.journal import Prefix

        report = health_check(Prefix(Path(prefix)))
        print(json.dumps({"ok": report.ok, "failed": [r.ident for r in report.failed]}, sort_keys=True))
    except Exception as exc:  # noqa: BLE001 - a hook must never break the session
        print(f"astplugin: health probe degraded: {type(exc).__name__}: {exc}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
