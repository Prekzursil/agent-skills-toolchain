---
name: astplugin
description: Install, update, repair, roll back, uninstall, sync, and diagnose the ast-integrate platform plugin.
---

# /astplugin

Lifecycle control for the ast-integrate platform plugin.

| command | what it does | safe to repeat |
|---|---|---|
| `astplugin build` | build the deterministic package | yes |
| `astplugin install --package <zip> --prefix <p>` | stage, verify, activate, deploy | no (fails if the version exists) |
| `astplugin update --package <zip> --prefix <p>` | new version, live overrides preserved | no |
| `astplugin repair --prefix <p>` | restore files with no live-unique content | yes |
| `astplugin rollback --prefix <p>` | activate the previous version | yes |
| `astplugin uninstall --prefix <p> --retain-user-data\|--purge-user-data` | remove | yes |
| `astplugin sync --prefix <p>` | live deployment synchronisation | yes |
| `astplugin cache --prefix <p> [--refresh\|--invalidate\|--verify]` | cache control | yes |
| `astplugin health-check --prefix <p> [--controls]` | probe registry + both-states control | yes |
| `astplugin conform --package <zip>` | conformance validator | yes |
| `astplugin migrate --prefix <p> [--dry-run]` | migrate an old layout | yes |
| `astplugin diagnose` | client / OS / shell compatibility | yes |
| `astplugin doctor --prefix <p>` | each failing probe -> its remediating command | yes |

Every mutating command accepts `--dry-run`. Every failure prints a stable `E_*` code, its cause,
its impact, and the exact next command; exit codes are one per failure class
(`astplugin errors --json -` prints the whole taxonomy).
