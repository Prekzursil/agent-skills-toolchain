#!/usr/bin/env python3
from probe2_both_states_latency import main

if __name__ == "__main__":
    raise SystemExit(main())
