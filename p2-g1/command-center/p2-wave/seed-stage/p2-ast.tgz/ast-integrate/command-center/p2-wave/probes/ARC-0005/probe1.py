#!/usr/bin/env python3
from probe1_divergence import main

if __name__ == "__main__":
    raise SystemExit(main())
