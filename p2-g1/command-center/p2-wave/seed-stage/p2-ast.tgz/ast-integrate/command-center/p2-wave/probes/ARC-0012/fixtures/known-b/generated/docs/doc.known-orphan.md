known B orphan
