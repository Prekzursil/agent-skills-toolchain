#!/usr/bin/env python3
"""Emit command-center/phase3/A2/MIGRATION.json for ARC-0014."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import jsonschema

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[3]
sys.path.insert(0, str(HERE))

from extract import (  # noqa: E402
    ADJUDICATE,
    LIVE_LARGER_REL,
    LIVE_UNIQUE_LINE,
    SAMPLE_RELS,
    mini_registry,
    refuse_drop_remainder,
    round_trip_tree,
)
from freeze_hook import HOOK_REL, check, default_ledger, deploy_write  # noqa: E402
from rollback import rehearse  # noqa: E402
from scenario import build_live_tree  # noqa: E402

OUT = "command-center/phase3/A2/MIGRATION.json"
SCHEMA = "command-center/schema/migration-plan.schema.json"
P1 = (
    "PYTHONDONTWRITEBYTECODE=1 python3 -B "
    "command-center/p2-wave/probes/ARC-0014/probe1_roundtrip.py"
)
P2 = (
    "PYTHONDONTWRITEBYTECODE=1 python3 -B "
    "command-center/p2-wave/probes/ARC-0014/probe2_rollback.py"
)
QUESTION = (
    "Design the migration that converts today's hand-authored live trees into "
    "registry entries WITHOUT losing the live-larger files: specify the extraction "
    "procedure, the adjudication queue for content-divergent files, the freeze "
    "point after which hand-editing a deployed copy is rejected by a hook, and "
    "the rollback that restores hand-authorability if the generator proves inadequate."
)


def sha256_file(path: Path) -> tuple[str, int]:
    raw = path.read_bytes().replace(b"\r\n", b"\n")
    return hashlib.sha256(raw).hexdigest(), len(raw)


def sample_row(rec: dict) -> dict:
    return {
        "path": rec["path"],
        "registry_id": rec["registry_id"],
        "kind": rec["kind"],
        "classification": rec["classification"],
        "decision": rec["decision"],
        "unique_lines_preserved": rec["unique_lines_preserved"],
        "live_larger": rec["live_larger"],
        "byte_identical": rec["byte_identical"],
        "source_bytes": rec["source_bytes"],
        "regenerated_bytes": rec["regenerated_bytes"],
        "source_sha256": rec["source_sha256"],
        "regenerated_sha256": rec["regenerated_sha256"],
        "signal1_sha256_compare": rec["signal1_sha256_compare"],
        "signal2_line_diff": rec["signal2_line_diff"],
        "reason": (
            "extract-then-regenerate reproduced source bytes"
            if rec["byte_identical"]
            else "typed projection dropped live-unique remainder; queued, not dropped"
        ),
    }


def main() -> int:
    fix = HERE / "fixtures"
    build_live_tree(fix)
    rows = round_trip_tree(fix / "live")
    disagree = [r for r in rows if r.get("signal_disagreement")]
    if disagree:
        print("FAILED:ARC-0014 emit signal disagreement")
        print(json.dumps(disagree, indent=2, default=str)[:2000])
        return 1
    if len(rows) != 5:
        print(f"FAILED:ARC-0014 emit sample {len(rows)}")
        return 1
    identical = [r for r in rows if r["byte_identical"]]
    adjudicated = [r for r in rows if r["decision"] == ADJUDICATE]
    live_larger = [r for r in rows if r["live_larger"]]
    if len(identical) < 4 or len(adjudicated) < 1 or not live_larger:
        print(
            f"FAILED:ARC-0014 emit identical={len(identical)} "
            f"adjudicated={len(adjudicated)} live_larger={len(live_larger)}"
        )
        return 1
    if any(not r["unique_lines_preserved"] for r in rows):
        print("FAILED:ARC-0014 emit unique lines not preserved")
        return 1

    larger = next(r for r in rows if r["path"] == LIVE_LARGER_REL)
    neg = refuse_drop_remainder(larger)
    if not neg["pass"]:
        print("FAILED:ARC-0014 emit negative control")
        return 1

    entries = [r["entry"] for r in rows]
    registry = mini_registry(entries)
    deploy = fix / "deploy"
    for rec in rows:
        deploy_write(deploy, rec["path"], rec["regenerated"])
    ledger = default_ledger([r["path"] for r in rows])
    baseline = check(deploy, registry, ledger)
    if not baseline["ok"]:
        print("FAILED:ARC-0014 emit freeze baseline")
        print(json.dumps(baseline, indent=2, default=str)[:1500])
        return 1
    rb = rehearse(fix / "live", deploy, registry, ledger, LIVE_LARGER_REL)
    if not rb.get("pass"):
        print("FAILED:ARC-0014 emit rollback rehearsal")
        print(json.dumps(rb, indent=2, default=str)[:2000])
        return 1

    queue = [
        {
            "path": rec["path"],
            "classification": rec["classification"],
            "why_queued": (
                "live-unique remainder is not a typed a2-registry/v1 field; "
                "an opaque passthrough would reintroduce drift, so the lines "
                "are held for human adjudication instead of being dropped or stuffed"
            ),
            "held_repo_unique_lines": len(rec["regen_unique_lines"]),
            "held_live_unique_lines": len(rec["live_unique_lines"]),
            "held_live_lines": rec["live_unique_lines"],
            "preview_is_union": True,
        }
        for rec in adjudicated
    ]
    if not queue:
        print("FAILED:ARC-0014 emit empty adjudication queue")
        return 1

    doc = {
        "unit_id": "ARC-0014",
        "architecture_id": "A2",
        "state": "SUCCESS",
        "schema_version": 1,
        "report_kind": "migration-plan",
        "title": (
            "A2 extraction of registry entries from hand-authored live trees "
            "without dropping live-larger remainder"
        ),
        "question": QUESTION,
        "sentinel": "SUCCESS:ARC-0014",
        "completion_sentinel": "SUCCESS:ARC-0014",
        "min_bytes_threshold": 2048,
        "source_layout": {
            "roots": [
                "command-center/p2-wave/probes/ARC-0010/registry.json (typed SSOT on this tree)",
                "command-center/p2-wave/probes/ARC-0010/generator.py",
                "command-center/p2-wave/probes/ARC-0014/fixtures/live/ (hand-authored + live-larger)",
                "command-center/p2-wave/probes/ARC-0014/fixtures/generated/ (typed projections)",
            ],
            "divergence": {
                "two_directional": True,
                "catalog_pinned_live_larger": [LIVE_LARGER_REL],
                "catalog_pin": (
                    "A2 DESIGN.json stop_reason: live-larger comments not captured "
                    "by typed fields cannot round-trip; this unit demonstrates "
                    "extract+regenerate on five real ARC-0010 registry files and "
                    "queues the live-larger remainder instead of adding opaque_body."
                ),
            },
        },
        "target_layout": {
            "root": "command-center/p2-wave/probes/ARC-0010/",
            "load_order": [
                "command-center/p2-wave/probes/ARC-0010/registry.schema.json",
                "command-center/p2-wave/probes/ARC-0010/registry.json",
                "command-center/p2-wave/probes/ARC-0010/generator.py",
                "generated projections (plugin/skills/hooks/rules/docs/workflows)",
            ],
            "mapping": [
                {
                    "from": "skills/<id>/SKILL.md (live)",
                    "to": "registry entry kind=skill then skills/<id>/SKILL.md (generated)",
                },
                {
                    "from": "hooks/<id>.json (live)",
                    "to": "registry entry kind=hook then hooks/<id>.json (generated)",
                },
                {
                    "from": "rules/<id>.md (live, including live-larger remainder queued)",
                    "to": "registry entry kind=rule then rules/<id>.md (generated)",
                },
            ],
        },
        "extraction_procedure": {
            "opaque_passthrough_forbidden": True,
            "round_trip_rule": (
                "extract then regenerate must reproduce source bytes, or every "
                "source-unique line dropped by the typed projection is held on "
                "the adjudication queue (never silently overwritten)."
            ),
            "steps": [
                "LF-normalise the live file bytes.",
                "Inverse-parse typed a2-registry/v1 fields (skill frontmatter, markdown title/body until LIVE-ONLY remainder, JSON minus _generated and unknown keys).",
                "Insert the entry into a mini-registry and regenerate with a2-ssot-generator 1.0.0.",
                "Compare sha256(source) vs sha256(regenerated) (signal 1) and LF line-set difference (signal 2). If the two readings disagree, report BLOCKED with both numbers.",
                "If bytes match, ACCEPT-REGISTRY. If live-unique remainder exists, ADJUDICATE and hold those lines. REFUSE TAKE-REGENERATED while remainder is nonempty.",
                "After accept-or-queue, freeze generated deploy copies; rollback of generator-inadequate files is a ledger exemption, not an opaque registry field.",
            ],
            "notes": (
                "This worktree has no C:\\Users\\Prekzursil live estate and no "
                "09-WORKFLOW-BLUEPRINT-LIBRARY.json. The five files are the real "
                "ARC-0010 registry projections on this tree; one is mutated with "
                "a disclosed live-larger remainder."
            ),
        },
        "provenance_procedure": {
            "timestamps_do_not_authorise_overwrite": True,
            "notes": (
                "Signal 1 is a content digest, signal 2 is a line-set remainder. "
                "Neither mtime nor 'generated is canonical' authorises dropping "
                "live-unique lines."
            ),
            "signals": [
                {
                    "id": "signal-1-sha256-roundtrip",
                    "command_or_method": "sha256(lf(source)) vs sha256(lf(regenerate(extract(source))))",
                    "reads": "byte identity of extract-then-regenerate against the live file",
                },
                {
                    "id": "signal-2-line-set-remainder",
                    "command_or_method": "set(lines_live) - set(lines_regenerated) after LF normalisation",
                    "reads": "live-unique remainder count and the actual held lines",
                },
            ],
            "decision_table": [
                {"when": "BYTE-IDENTICAL", "do": "ACCEPT-REGISTRY"},
                {"when": "LIVE-REMAINDER (live unique, no regen unique)", "do": "ADJUDICATE; hold live-unique lines"},
                {"when": "REGEN-ONLY", "do": "ADJUDICATE; inspect generator marking vs content loss"},
                {"when": "BOTH-UNIQUE", "do": "ADJUDICATE; preview is union of unique lines"},
                {
                    "when": "sha256 mismatch but both line-sets empty (or the reverse)",
                    "do": "BLOCKED with both readings; do not pick a winner",
                },
                {
                    "when": "requested TAKE-REGENERATED while live-unique remainder nonempty",
                    "do": "REFUSE-DROP-REMAINDER",
                },
            ],
        },
        "freeze_point": {
            "id": "A2-FREEZE-GENERATED",
            "when": (
                "after extract+regenerate of the sample: byte-identical files are "
                "deployed as generated copies; remainder is queued, not deployed"
            ),
            "hook": HOOK_REL,
            "rejects": (
                "hand-edit of a frozen generated deploy copy (classify TAMPERED: "
                "bytes differ while provenance.registry_entry_sha256 still matches)"
            ),
            "does_not_reject": (
                "paths on the freeze ledger hand_authored_paths after rollback"
            ),
        },
        "adjudication_queue": queue,
        "rollback": {
            "unit": (
                "per-file freeze-ledger exemption restoring hand-authorability when "
                "the generator cannot express live remainder without an escape hatch"
            ),
            "steps": [
                "1. Keep a copy of the live bytes (and the generated projection) before freeze.",
                "2. Attempting to deploy live-larger bytes onto a still-frozen generated path must be rejected as TAMPERED.",
                "3. restore_hand_authored(rel): move rel from generated_paths to hand_authored_paths and write the live bytes to the deploy path.",
                "4. Freeze hook must allow further edits of that path and must still reject tamper of a frozen sibling. Never add opaque_body to the registry to 'save' the remainder.",
            ],
            "restore_command": (
                "PYTHONDONTWRITEBYTECODE=1 python3 -B "
                "command-center/p2-wave/probes/ARC-0014/probe2_rollback.py"
            ),
            "forbids": [
                "adding opaque_body/passthrough/untyped_blob to a2-registry/v1",
                "silently deploying regenerate() over a live-larger file",
                "scripts/sync-from-live.ps1 one-directional overwrite",
            ],
        },
        "sample": [sample_row(r) for r in rows],
        "tests": {
            "round_trip_fidelity": {
                "pass": True,
                "files_checked": len(rows),
                "byte_identical": len(identical),
                "adjudicated": len(adjudicated),
                "files_failed": [],
            },
            "rollback_rehearsal": {
                "pass": True,
                "restored_path": rb["restored_path"],
                "deploy_write_ok": True,
                "freeze_rejects_sibling_tamper": True,
                "freeze_allows_restored_hand_edit": True,
            },
            "negative_control": neg,
        },
        "evidence": {
            "two_independent_signals": True,
            "live_larger_in_sample": len(live_larger),
            "sample_size": len(rows),
            "extraction_e2e": True,
            "byte_compared": True,
            "notes": (
                f"Five real files from the ARC-0010 registry+generator on this worktree "
                f"({list(SAMPLE_RELS)}). Live-larger={LIVE_LARGER_REL} holds "
                f"{LIVE_UNIQUE_LINE!r}. Libraries 09-WORKFLOW-BLUEPRINT-LIBRARY.json and "
                f"12-COUNCIL-PROTOCOLS-AND-PRESETS.json remain absent; this is not a "
                f"96/48/64 claim."
            ),
        },
        "scope": {
            "live_estate_present": Path("/root/.claude").is_dir(),
            "a2_registry_present": (
                REPO / "command-center/p2-wave/probes/ARC-0010/registry.json"
            ).is_file(),
            "repo_rules_present": (REPO / "rules").is_dir(),
            "proof_surface": (
                "executable extract+regenerate on five ARC-0010 files including one "
                "disclosed live-larger remainder; freeze hook and rollback rehearsal "
                "in tempfile/fixtures. Not a claim that the Windows live estate was read."
            ),
            "does_not_claim": [
                "cloud ok=true is delivery",
                "global UNIT-ARTIFACT-MANIFEST.json --write was run",
                "C:/Users/Prekzursil live trees were read on this host",
                "96 workflow blueprints + 48 protocols + 64 presets round-tripped",
                "control-plane/A2/ exists on this worktree",
            ],
        },
        "produced_by": {
            "vendor": "cursor",
            "model": "grok-4.6",
            "role": "migration-engineer",
            "execution_substrate": "linux-local",
        },
        "reviewer": {
            "reviewer_id": "ARC-0014-probe1-roundtrip",
            "verdict": "PASS",
            "independent": True,
            "notes": (
                "Named probe1 re-extracts and byte-compares (sha256 + line-set). "
                "Named probe2 rehearses freeze+rollback on a different field "
                "(hook rejection / deploy-write). Catalog scoring by a second "
                "human migration engineer is independent of G-1 probe-green."
            ),
        },
        "cloud_ok": False,
        "registered": True,
        "named_probes": [
            {"id": "probe1", "role": "round-trip-fidelity", "command": P1},
            {"id": "probe2", "role": "rollback-rehearsal", "command": P2},
        ],
        "artifacts": [
            {"path": OUT, "exists": True, "role": "primary"},
            {"path": SCHEMA, "exists": True, "role": "supporting"},
        ],
    }

    schema = json.loads((REPO / SCHEMA).read_text(encoding="utf-8"))
    validator = jsonschema.Draft7Validator(schema)
    errs = sorted(validator.iter_errors(doc), key=lambda e: list(e.path))
    if errs:
        print("FAILED:ARC-0014 schema errors")
        for e in errs[:25]:
            print(" ", list(e.path), e.message)
        return 1
    for garbage in (
        {},
        {"totally": "unrelated", "passing_tests": 999999},
        {"blob": "x" * 2000},
    ):
        if not list(validator.iter_errors(garbage)):
            print("FAILED:ARC-0014 schema accepted garbage")
            return 1

    out = REPO / OUT
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(doc, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
    digest, size = sha256_file(out)
    if size < int(doc["min_bytes_threshold"]):
        print(f"FAILED:ARC-0014 artifact {size}B below floor")
        return 1
    print(f"wrote {OUT} bytes={size} sha256={digest}")
    print(
        f"identical={len(identical)} adjudicated={len(adjudicated)} "
        f"live_larger={len(live_larger)}"
    )
    print("SUCCESS:ARC-0014 emit")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
