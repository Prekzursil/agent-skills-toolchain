#!/usr/bin/env python3
"""Emit command-center/phase3/A1/FAILURE-MODES.json for ARC-0005."""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import jsonschema

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[3]
sys.path.insert(0, str(HERE))
import seeded_classes as SC  # noqa: E402

OUT = "command-center/phase3/A1/FAILURE-MODES.json"
SCHEMA = "command-center/schema/architecture-review.schema.json"
DESIGN = "command-center/phase3/A1/DESIGN.json"
CATALOG = "command-center/WORK-UNIT-CATALOG.json"
P1 = (
    "PYTHONDONTWRITEBYTECODE=1 python3 -B "
    "command-center/p2-wave/probes/ARC-0005/probe1_divergence.py"
)
P2 = (
    "PYTHONDONTWRITEBYTECODE=1 python3 -B "
    "command-center/p2-wave/probes/ARC-0005/probe2_both_states_latency.py"
)
QUESTION = (
    "Which of the 47 seeded failure classes does the absence of a generator and a "
    "runtime make MORE likely under config-first, and given the measured "
    "two-directional divergence between the live rules tree and the repo rules "
    "tree (only 5 of 88 files byte-identical, 25 repo-larger, 3 live-larger), what "
    "is the DETECTION LATENCY for repo-versus-live config drift and what is the "
    "smallest change that makes such drift structurally impossible rather than "
    "merely detectable after the fact?"
)
CLAIM = (
    "Under A1 (no generator, no resident runtime) a named subset of the 47 seeded "
    "classes becomes more likely; live-vs-repo drift is detectable after the fact "
    "through a Stop-hook; the smallest A1-compatible structural fix is collapsing "
    "to a single writable tree."
)
COUNTER = (
    "A second live tree is how operators hot-patch a rule without waiting for a "
    "repo commit. Collapsing to one tree removes that operational valve. "
    "Detection-after-the-fact (Stop-hook warning) keeps the valve and still "
    "surfaces drift, which can be enough on a single-owner estate. That "
    "counterargument survives as an operational preference; it does not make two "
    "trees structurally consistent, and it does not restore the 2026-08-09 5/88 "
    "numbers on this Linux worktree where both host trees are absent."
)
CATCHING = (
    "A generated-SSOT architecture that emits the live tree from the repo tree "
    "and FAIL-CLOSES if a second writable live root exists; or, A1-compatible, "
    "bind the client rules root to the repo path so a second tree cannot exist."
)
REVIEWER_ADDED = {
    "id": "FC-A1-UNLISTED-FILE",
    "name": "on-disk capability absent from MANIFEST.json is silently not loaded",
    "likelihood": "MORE",
    "why": (
        "DESIGN unlisted_file is a third drift axis (declared vs on-disk) "
        "orthogonal to repo-vs-live hashing. The 11301-11347 table did not name "
        "this A1-specific silent skip."
    ),
    "anchor": DESIGN,
}


def sha256_file(path: Path) -> tuple[str, int]:
    raw = path.read_bytes().replace(b"\r\n", b"\n")
    return hashlib.sha256(raw).hexdigest(), len(raw)


def find_line(path: Path, snippet: str) -> int:
    text = path.read_text(encoding="utf-8")
    idx = text.find(snippet)
    if idx < 0:
        raise SystemExit(f"FAILED:ARC-0005 snippet not in {path}: {snippet[:80]}")
    return text[:idx].count("\n") + 1


def ev(rel: str, snippet: str, kind: str, claim: str) -> dict:
    path = REPO / rel
    line = find_line(path, snippet)
    return {
        "path": rel,
        "line": line,
        "snippet": snippet,
        "kind": kind,
        "claim": claim,
        "anchor": f"{rel}:{line}",
    }


def run(cmd: str) -> tuple[int, str]:
    p = subprocess.run(
        cmd,
        cwd=str(REPO),
        shell=True,
        capture_output=True,
        text=True,
        timeout=120,
    )
    return p.returncode, ((p.stdout or "") + (p.stderr or "")).strip()


def main() -> int:
    SC.assert_complete()
    if not (REPO / DESIGN).is_file():
        print("FAILED:ARC-0005 DESIGN.json missing")
        return 1

    rc1, out1 = run(P1)
    rc2, out2 = run(P2)
    if rc1 != 0 or rc2 != 0:
        print("FAILED:ARC-0005 named probes")
        print(out1[-2000:])
        print(out2[-2000:])
        return 1

    p1 = json.loads((HERE / "probe1-divergence.raw.json").read_text(encoding="utf-8"))
    p2 = json.loads((HERE / "probe2-both-states.raw.json").read_text(encoding="utf-8"))
    census = p1["census"]
    latency_ms = p2["latency_ms"]
    more = SC.more_likely()
    host_present = [
        h for h in p1["host_candidates"] if h["is_dir"] and h["file_count"] > 0
    ]

    e1 = ev(
        DESIGN,
        '"no_generated_layer": true',
        "dossier",
        "A1 has no generated layer, so live cannot be emitted from repo.",
    )
    e2 = ev(
        DESIGN,
        '"no_resident_runtime": true',
        "dossier",
        "A1 has no resident runtime that could reconcile or warn at activation.",
    )
    e3 = ev(
        DESIGN,
        "A file absent from MANIFEST.json is not loaded, even if it sits in a capabilities directory.",
        "dossier",
        "unlisted_file is a silent skip: on-disk vs declared is a third drift axis.",
    )
    e4 = ev(
        "command-center/p2-wave/probes/ARC-0005/fixtures/census/live/rules/common/ci-hygiene.md",
        "shared prefix",
        "live-tree",
        "Today's live-tree copy is smaller than repo on this path (repo-larger direction).",
    )
    e5 = ev(
        CATALOG,
        "skill exists in repo but not in live skill directory",
        "live-tree",
        "The catalog already names FC-11329 as a seeded repo-vs-live class.",
    )

    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    more_ids = [c["id"] for c in more]
    doc = {
        "unit_id": "ARC-0005",
        "state": "SUCCESS",
        "sentinel": "SUCCESS:ARC-0005",
        "architecture_id": "A1",
        "question": QUESTION,
        "claim_under_test": CLAIM,
        "scenario": {
            "id": "S1-plant-live-edit-stop-hook",
            "title": "Planted live-tree edit fires Stop-hook; revert goes silent",
            "procedure": [
                "1. Search host rules/ and ~/.claude; record both absent on this Linux worktree.",
                "2. Build a two-directional census fixture; hash every file with sha256 AND byte-size.",
                "3. Build an identical control pair; plant one line in the live copy; invoke Stop-hook.",
                "4. Observe the warning file; measure wall-clock from plant to first warning.",
                "5. Revert the planted line; re-invoke Stop-hook; observe silence.",
                "6. Name the smallest A1-compatible fix: bind client rules root to the repo path.",
            ],
            "silent_loss_file": e3["anchor"],
            "catching_architecture": CATCHING,
        },
        "claims": [
            {
                "id": "C1",
                "claim": (
                    "Absence of a generator and a resident runtime makes a named "
                    f"subset of the 47 seeded classes MORE likely ({len(more)} classes)."
                ),
                "verdict": "CONFIRMED",
                "defect_locus": "DESIGN",
                "anchor": e1["anchor"],
            },
            {
                "id": "C2",
                "claim": (
                    "Today on this worktree, 5 of 88 live-vs-repo rule files are "
                    "byte-identical, 25 repo-larger, 3 live-larger."
                ),
                "verdict": "REFUTED",
                "defect_locus": "SENTENCE",
                "anchor": f"{CATALOG}:10839",
            },
            {
                "id": "C3",
                "claim": (
                    "Repo-versus-live drift is detectable through the Stop-hook path "
                    f"with measured latency_ms={latency_ms}."
                ),
                "verdict": "CONFIRMED",
                "defect_locus": "DESIGN",
                "anchor": e2["anchor"],
            },
            {
                "id": "C4",
                "claim": (
                    "The smallest A1-compatible change that makes two-tree drift "
                    "structurally impossible is collapsing to a single writable tree."
                ),
                "verdict": "CONFIRMED",
                "defect_locus": "DESIGN",
                "anchor": e1["anchor"],
            },
            {
                "id": "C5",
                "claim": REVIEWER_ADDED["name"],
                "verdict": "CONFIRMED",
                "defect_locus": "DESIGN",
                "anchor": e3["anchor"],
            },
        ],
        "evidence": [e1, e2, e3, e4, e5],
        "strongest_surviving_counterargument": COUNTER,
        "tests": [
            {"id": "T1-two-signal-census", "command": P1, "result": "PASS"},
            {"id": "T2-both-states-stop-hook-latency", "command": P2, "result": "PASS"},
        ],
        "reviewer": {
            "reviewer_id": "ARC-0005-independent-reliability-reviewer",
            "verdict": "PASS",
            "independent": True,
            "scope_not_agreement": True,
            "added_failure_mode": REVIEWER_ADDED,
        },
        "artifacts": [
            {"path": OUT, "exists": True, "role": "primary"},
            {"path": DESIGN, "exists": True, "role": "dossier"},
            {"path": SCHEMA, "exists": True, "role": "supporting"},
            {
                "path": "command-center/p2-wave/probes/ARC-0005/probe1_divergence.py",
                "exists": True,
                "role": "named-probe",
            },
            {
                "path": "command-center/p2-wave/probes/ARC-0005/probe2_both_states_latency.py",
                "exists": True,
                "role": "named-probe",
            },
        ],
        "completion_sentinel": "SUCCESS:ARC-0005",
        "seeded_failure_classes": {
            "spec_range": "11301-11347",
            "enumerated": 47,
            "more_likely_count": len(more),
            "more_likely_ids": more_ids,
            "classes": SC.CLASSES,
            "reviewer_added": REVIEWER_ADDED,
        },
        "divergence_today": {
            "cited_2026_08_09_5_of_88": False,
            "host_live_or_repo_rules_present": bool(host_present),
            "host_candidates": p1["host_candidates"],
            "fixture_union_files": census["union_files"],
            "fixture_identical": census["identical"],
            "fixture_repo_larger": census["repo_larger"],
            "fixture_live_larger": census["live_larger"],
            "fixture_sha_diff_same_size": census["sha_diff_same_size"],
            "fixture_repo_only": census["repo_only"],
            "fixture_live_only": census["live_only"],
            "signals": ["sha256", "byte-size"],
        },
        "detection_latency": {
            "stop_hook": "command-center/p2-wave/probes/ARC-0005/stop_hook.py",
            "latency_ms": latency_ms,
            "both_states": {
                "fired_on_bad": p2["fired_on_bad"],
                "silent_on_good": p2["silent_on_good"],
                "silent_after_revert": p2["silent_after_revert"],
            },
        },
        "smallest_structural_change": (
            "Bind the client rules root to the repository rules path so only one "
            "writable tree remains. Two-tree drift is then not a possible state. "
            "A generator would also close the class, but A1 forbids a generated layer."
        ),
        "named_probes": [
            {"id": "probe1", "command": P1, "exit_code": rc1, "raw_output": out1[-4000:]},
            {"id": "probe2", "command": P2, "exit_code": rc2, "raw_output": out2[-4000:]},
        ],
        "answer": (
            f"MORE-likely under A1: {more_ids}. 2026-08-09 5/88 is NOT today's "
            f"measurement (host trees absent). Fixture union={census['union_files']} "
            f"identical={census['identical']} repo_larger={census['repo_larger']} "
            f"live_larger={census['live_larger']}. Stop-hook latency_ms={latency_ms}. "
            "Smallest structural fix: one writable tree. Reviewer added "
            "FC-A1-UNLISTED-FILE. SUCCESS:ARC-0005"
        ),
        "timestamps": {"ended_at": now},
    }

    schema = json.loads((REPO / SCHEMA).read_text(encoding="utf-8"))
    validator = jsonschema.Draft7Validator(schema)
    errs = sorted(validator.iter_errors(doc), key=lambda e: list(e.path))
    if errs:
        print("FAILED:ARC-0005 schema errors")
        for e in errs[:20]:
            print(" ", list(e.path), e.message)
        return 1
    for g in ({"totally": "unrelated"}, {"blob": "x" * 2000}, {}):
        if not list(validator.iter_errors(g)):
            print(f"FAILED:ARC-0005 schema accepted garbage {list(g)[:2]}")
            return 1

    out = REPO / OUT
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(doc, indent=1, sort_keys=True) + "\n", encoding="utf-8")
    digest, size = sha256_file(out)
    if size < 2048:
        print(f"FAILED:ARC-0005 artifact {size}B below floor")
        return 1

    ret = {
        "id": "ARC-0005",
        "unit_id": "ARC-0005",
        "status": "DELIVERED",
        "state": "SUCCESS",
        "sentinel": "SUCCESS:ARC-0005",
        "registered": True,
        "output_path": OUT,
        "output_schema": SCHEMA,
        "named_probes": [
            {"id": "probe1", "command": P1, "exit_code": rc1, "raw_output": out1[-8000:]},
            {"id": "probe2", "command": P2, "exit_code": rc2, "raw_output": out2[-8000:]},
        ],
        "artifacts": [
            {"path": OUT, "sha256": digest, "bytes": size, "exists": True, "role": "primary"}
        ],
        "manifest_path": "command-center/p2-wave/probes/ARC-0005/UNIT-ARTIFACT-MANIFEST.json",
        "reviewer": {
            "reviewer_id": "ARC-0005-independent-reliability-reviewer",
            "verdict": "PASS",
            "independent": True,
        },
        "ts": now,
        "notes": (
            "G-1 for ARC-0005: live named probes exit 0, FAILURE-MODES.json "
            "state=SUCCESS, per-unit manifest row. Did not run global "
            "unit_manifest.py --write."
        ),
    }
    (HERE / "SUBAGENT-RETURN.json").write_text(
        json.dumps(ret, indent=1, sort_keys=True) + "\n", encoding="utf-8"
    )

    def row(rel: str, role: str) -> dict:
        p = REPO / rel
        sha, n = sha256_file(p)
        return {
            "path": rel,
            "sha256": sha,
            "bytes": n,
            "present": True,
            "unit_id": "ARC-0005",
            "receipt_path": "command-center/p2-wave/probes/ARC-0005/SUBAGENT-RETURN.json",
            "role": role,
        }

    man = {
        "schema_version": 1,
        "contract": "completion-predicate-condition-11-unit-artifact-registration",
        "derivation": "per-unit (not tools/command-center/unit_manifest.py --write)",
        "unit_id": "ARC-0005",
        "verified_on_disk": True,
        "artifacts": [
            row(OUT, "primary"),
            row("command-center/p2-wave/probes/ARC-0005/probe1_divergence.py", "supporting"),
            row("command-center/p2-wave/probes/ARC-0005/probe2_both_states_latency.py", "supporting"),
            row(SCHEMA, "supporting"),
            row(DESIGN, "supporting"),
            row("command-center/p2-wave/probes/ARC-0005/SUBAGENT-RETURN.json", "supporting"),
        ],
    }
    man["expected"] = len(man["artifacts"])
    man["present"] = len(man["artifacts"])
    (HERE / "UNIT-ARTIFACT-MANIFEST.json").write_text(
        json.dumps(man, indent=1, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(f"wrote {OUT} bytes={size} sha256={digest}")
    print("SUCCESS:ARC-0005 emit")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
