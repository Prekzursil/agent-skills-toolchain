def marker():
    return 'planted-without-sbom-regen'
