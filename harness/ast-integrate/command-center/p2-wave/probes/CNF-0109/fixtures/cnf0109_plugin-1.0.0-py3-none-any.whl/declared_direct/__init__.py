from declared_transitive import helper

def ping():
    return helper()
