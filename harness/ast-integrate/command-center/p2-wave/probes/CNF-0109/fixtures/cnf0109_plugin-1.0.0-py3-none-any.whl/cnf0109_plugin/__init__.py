from declared_direct import ping

def run():
    return ping()
